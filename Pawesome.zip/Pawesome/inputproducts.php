



<!doctype html>

<html>

<head>
<title>
170104093

</title>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="stylesheet" href="css/bootstrap.min.css">

</head>

<body>


<div class="firstlastname">

<form action="includes/inputproduct.inc.php" method="post" enctype="multipart/form-data">


<label> ENTER Product PIC* </label>
<input type="file" class="form-control" name="product_img" placeholder="example@example" />
<div class="name">

</div>

<label> ENTER Product name </label>
<input type="text" class="form-control" name="product_name" placeholder="Eg-1800 0000" />
<div>
<label> ENTER Product category</label>
<select name="product_category"> 
<option value="Dog Food"> Dog Food </option>
<option value="Bird Food"> Cat food  </option>
<option value="Fish Food"> Fish Food </option>
<option value="Cat accessories"> Cat accessories  </option>
<option value="Dog accessories"> Dog accessories  </option>
<option value="Fish accessories"> Fish accessories  </option>
<option value="Bird accessories"> Bird accessories  </option>
 </select>

</div>

<label> ENTER price * </label>
<input type="number" class="form-control" name="product_price" placeholder="Eg-1800 0000" />

<label> ENTER quantity * </label>
<input type="number" class="form-control" name="product_qty" placeholder="Eg-1800 0000" />

<label> ENTER description * </label>
<input type="number" class="form-control" name="product_desc" placeholder="Eg-1800 0000" />



<div class="button">
<button type="submit" name="inputbtn" class="btn btn-default"> INPUT </button>

</div>
</form>

</div>
	




</body>


</html>