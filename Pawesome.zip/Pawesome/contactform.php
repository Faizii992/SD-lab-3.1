<?php


if(isset($_POST['submit']))
{
	
	$name=$_POST['username'];
		$mailfrom=$_POST['email'];
			$message=$_POST['message'];
			$mailfrom=$_POST['email'];
				$subject=$_POST['subject'];
			$mailto="faiizii992@gmail.com";
			
			$headers="From: ".$mailfrom;
$txt="You have received an E-mail from ".$name.".\n\n".$message;
			
			
	mail($mailto,$subject,$txt,$headers);
	header("Location: contactpage.php?mailsend");
	
}









?>