
<?php

include "includes/db.inc.php";
session_start();

$uid=$_SESSION['userid'];
$uname=$_SESSION['userUid'];

if(isset($_POST['cat']))
	
	{
		
		
		
		
	}


$result=mysqli_query($conn,"SELECT * FROM users WHERE idusers='$uid'");
$retrieve=mysqli_fetch_array($result);
//print_r($retrieve);

$id=$retrieve['idusers'];
$uid=$retrieve['uidusers'];
$emailusers=$retrieve['emailusers'];
$address=$retrieve['address'];
$gender=$retrieve['gender'];
$number=$retrieve['number'];
$profilepic=$retrieve['profilepic'];
$firstname=$retrieve['firstname'];
$lastname=$retrieve['lastname'];
$bio=$retrieve['bio'];
$workedu=$retrieve['work_edu'];


?>

