
<?php

//session_start();

?>



<!DOCTYPE html>

<head>

<title> pAwesome Care </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" type="text/css" href="css/header.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/swiper.min.css">
<link rel="stylesheet" href="css/swiper.css">
   



</head>



<body>

<div class="headerdiv">







<?php

if(isset($_SESSION['userid']))
{
	
echo '
		
	<div class="stickyheader">
		<div class="topnav">
<div class="login_container">
    <form  action="includes/logout.inc.php">
      
	  
	  
	  
      <button id="logout" class="btn btn-default" type="submit">LOGOUT</button>
	
    </form>
  </div>

</div>



<div id="navbar">
  <a href="index.php">HOME</a>
    <a href="#home">TEAM</a>
	 <a href="#home">GALLERY</a>
  <a href="vetconsult.php">VET CONSULTATION</a>
  <a href="contactpage.php">CONTACT</a>
    <a href="shoppingpage2.php">PET MART</a>
	  <a href="profpage.php">PROFILE</a>
</div>
  
  </div>
  
  ';

	
	
}
else
{
	
	
		echo '
		
	<div class="stickyheader">
		<div class="topnav">
<div class="login_container">
    <form action="includes/login.inc.php">
      
	  
	  
	  
      <button id="login" class="btn btn-default" type="submit">LOGIN</button>
	   <button id="register" class="btn btn-default" type="submit">REGISTER</button>
    </form>
  </div>

</div>



<div id="navbar">
  <a href="index.php">HOME</a>
    <a href="#home">TEAM</a>
	 <a href="#home">GALLERY</a>
  <a href="vetconsult.php">VET CONSULTATION</a>
  <a href="contactpage.php">CONTACT</a>
    <a href="shoppingpage2.php">PET MART</a>
</div>
  
  </div>
  ';
  


	
}



?>




<div class="logowithinfo">
<img src="images/logomain.png">


<div class="infobox">

<img src="images/icon4.png">

<div class="info">
<h1> OUR LOCATION </h1>
<p> 2418,NANCY NY </p>

</div>

</div>

<div class="infobox">

<img src="images/icon4.png">
<div class="info">
<h1> OUR LOCATION </h1>
<p> 2418,NANCY NY </p>

</div>
</div>

<div class="infobox">

<img src="images/icon4.png">
<div class="info">
<h1> OUR LOCATION </h1>
<p> 2418,NANCY NY </p>

</div>
</div>

</div>

<center>

  </center>
  
  
  </div>
</body>



</html>

