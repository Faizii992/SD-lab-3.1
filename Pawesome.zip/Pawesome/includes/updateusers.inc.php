<?php

	require 'db.inc.php';
session_start();
$uid=$_SESSION['userid'];
$uname=$_SESSION['userUid'];


if(isset($_POST['savechanges']))
{
	
	
	
	$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["profilepic"]["name"]);
move_uploaded_file ($_FILES["profilepic"]["tmp_name"], $target_file);
		
	//$id=$POST['id'];
//$result=mysqli_query($conn,"UPDATE 'users' SET emailusers='$_POST['email']',address='$_POST['address']',gender='$_POST['gender']',number='$_POST['number']',profilepic='$_FILES['profilepic']',firstname='$_POST['firstname']',lastname='$_POST['lastname']',bio='$_POST['bio']' WHERE idusers='$uid'");

$result=mysqli_query($conn,"UPDATE users SET emailusers='$_POST[email]',profilepic='$target_file',address='$_POST[address]',number='$_POST[number]',firstname='$_POST[firstname]',lastname='$_POST[lastname]',bio='$_POST[bio]' WHERE idusers='$uid'");


}


?>


<!DOCTYPE html>


<head>

<title> Assignment 3 Form </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet"  href="css/profpagecard.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>



<body>

	
	</body>
	
	
	</html>