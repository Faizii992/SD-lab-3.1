<?php

if(isset($_POST['login']))
{
	
	require 'db.inc.php';
	
	$emailidusers=$_POST['email1'];
	
	$password=$_POST['password1'];
	
	
	if(empty($emailidusers) || empty($password))
{
	
	header("Location: ../reglog.php?error=emptyfields");
	exit();
	
}

else
{
	
	$sql="SELECT * FROM users WHERE uidusers=? OR emailusers=?;";
	

	$stmt=mysqli_stmt_init($conn);
	if(!mysqli_stmt_prepare($stmt,$sql))
	{
		header("Location: ../reglog.php?error=sqlerror");
		
		exit();
	}
	else
	{
		mysqli_stmt_bind_param($stmt,"ss",$emailidusers,$emailidusers);
		mysqli_stmt_execute($stmt);
		$result=mysqli_stmt_get_result($stmt);
		
		if($row=mysqli_fetch_assoc($result))
		{
			$pwdcheck=password_verify($password,$row['pwdusers']);
			if($pwdcheck==false)
			{
				header("Location: ../reglog.php?error=wrongpwd");
		
		exit();	
			}
			
			
			else if($pwdcheck==true)
		{
				session_start();
	$_SESSION['userid']=$row['idusers'];
		$_SESSION['userUid']=$row['uidusers'];
			$_SESSION['email']=$row['emailusers'];
				$_SESSION['address']=$row['address'];
		$_SESSION['number']=$row['number'];
		
			
					header("Location: ../profpage.php?login=LOGINSUCCESS!!");
					exit();
			
		}
		
		else
		{
			
					header("Location: ../reglog.php?error=wrongpwd");
		
		exit();	
		}
		
			
			
		}
		
		
		
	}
	
}

}	
	else
	{
		header("Location: ../reglog.php?");
		exit();
		
		
		
	}
	
	
	











