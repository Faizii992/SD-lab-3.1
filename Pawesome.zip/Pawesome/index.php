<?php



session_start();


?>

<!DOCTYPE html>

<html>

<head>

<title> pAwesome Care </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" type="text/css" href="css/Homepage.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/swiper.min.css">
<link rel="stylesheet" href="css/swiper.css">
   
<?php

require "header.php";

?>


  <style>
    body {
   
      font-family: Helvetica Neue, Helvetica, Arial, sans-serif;
      font-size: 14px;
     
      margin: 0;
      padding: 0;
    }
    .swiper-container {
      width: 100%;
	 
	padding-top:7%;
	padding-bottom:7%;

    }
	
    .swiper-slide {
		
	
      background-position: center;
      background-size: cover;
      width: 550px;
      height: 650px;
	border-radius:5%;

    }
  </style>

</head>


<body>




<div class="slideshow-container">

<div class="mySlides fade">

  <img src="images/look2.jpg" style="width:100%">
  
  <div class="slideshowtext">
  <h1>ANY KIND OF HEALTH PROBLEM OR EMERGENCY?</h1>

	
	</div>
</div>

<div class="mySlides fade">

  <img src="images/veta.jpg" style="width:100%">
   <h1>ANY KIND OF HEALTH PROBLEM OR EMERGENCY?</h1>
    
</div>

<div class="mySlides fade">

  <img src="images/groupofdogs.jpg" style="width:100%">
  <h1>ANY KIND OF HEALTH PROBLEM OR EMERGENCY?</h1>

</div>


</div>
<div class="service_slides">


<div class="ourservices">
<h1 class="our"> OUR</h1>
<h1 class="services"> SERVICES</h1>
</div>

  <div class="swiper-container">
    <div class="swiper-wrapper">
         <div class="swiper-slide" style="background-image:url(images/ordog.jpg)">
		   <h1> Buy Food for your dog at the cheapest rate </h1>
	  	 <button onclick="location.href = 'http://localhost/Pawesome/productdetails.php';" type="button" class="btn btn-info">View Details</button>
		 
		 </div>
          <div class="swiper-slide" style="background-image:url(images/scottishcat.jpg)">
		  
		    <h1> Buy Food for your dog at the cheapest rate </h1>
	  	  	 <button onclick="location.href = 'http://localhost/Pawesome/productdetails.php';" type="button" class="btn btn-info">View Details</button>
		  
		  </div>
		           <div class="swiper-slide" style="background-image:url(images/yellowdog.jpg)">
				   
				     <h1> Buy Food for your dog at the cheapest rate </h1>
					 
					 
				<?php	 
					 if(isset($_SESSION['userid']))
{
	
	
					 
	  echo'<button onclick="location.href = "http://localhost/Pawesome/productdetails.php";" type="button" class="btn btn-info">View Details</button>';	
}
else
{		 
	  echo'<button onclick="location.href = "http://localhost/Pawesome/productdetails.php";" type="button" class="btn btn-info">View Details</button>';	
}


		?>			 
					 
				   </div>
          <div class="swiper-slide" style="background-image:url(images/whiterabbit.jpg)">
		  
		    <h1> SEE A VET FOR ANY KINDOF PROBLEM </h1>
	  			<?php	 
					 if(isset($_SESSION['userid']))
{
	
	
					 
	  echo'<button onclick="location.href = "http://localhost/Pawesome/productdetails.php";" type="button" class="btn btn-info">View Details</button>';	
}
else
{		 
	  echo'     <button onclick="location.href = "http://localhost/Pawesome/productdetails.php";" type="button" class="btn btn-info">View Details</button>';	
}


		?>			 
			
		  
		  </div>
		      <div class="swiper-slide" style="background-image:url(images/scottishcat.jpg)">
			  
			    <h1> Buy Food for your dog at the cheapest rate </h1>
	       <button onclick="location.href = "http://localhost/Pawesome/productdetails.php";" type="button" class="btn btn-info">View Details</button>
			  
			  </div>
       
    </div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
  </div>


</div>
  <!-- Swiper JS -->
  <script src="js/swiper.min.js"></script>

  <!-- Initialize Swiper -->
  <script>
    var swiper = new Swiper('.swiper-container', {
      effect: 'coverflow',
      grabCursor: true,
      centeredSlides: true,
      slidesPerView: 'auto',
      coverflowEffect: {
        rotate: 5,
        stretch: 0,
        depth: 150,
        modifier: 3,
       
      },
      pagination: {
        el: '.swiper-pagination',
      },
    });
  </script>
  
    <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  
  <script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>
  
  

<!--



<div class="footerdiv">

<h1> COPYRIGHTED </h1>

</div>


</body>

-->







<div class="DIDYOUKNOW">

<div class="ourservices">
<h1 class="our"> DID</h1>
<h1 class="services"> YOU KNOW?</h1>
</div>

<div class="container-fluid">
<div class="row">
<div class="col-md-6">

<img src="images/signs.jpg">

</div>


<div class="col-md-6">

<img src="images/poisonous.jpg">

</div>


<div class="col-md-6">

<img src="images/catfacts.jpg">

</div>





<div class="col-md-6">

<img src="images/dogvscats.jpg">

</div>




</div>
</div>
</div>
</html>




<?php

require "footer.php";

?>

