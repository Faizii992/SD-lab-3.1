<!DOCTYPE html>

<html>

<head>

<title> pAwesome Care </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" type="text/css" href="css/Homepage.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>


<body>


<div class="headerdiv">

<img src="images/logomain.png">

<div class="headermenu">
<ul>

<li a> HOME </li>
<li a> SERVICE </li>
<li a> GALLERY </li>
<li a> CONTACT </li>
<li a> ABOUT </li>
<li a> TEAM </li>

</ul>

</div>


</div>

<div class="animalslook">

<img src="images/look2.jpg">

</div>








<div class="footerdiv">

<h1> COPYRIGHTED </h1>

</div>


</body>




</html>
