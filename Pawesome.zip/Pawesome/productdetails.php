
<?php

include "includes/db.inc.php";
session_start();

	$product_spec=$_SESSION['productspec'];


$result=mysqli_query($conn,"SELECT * FROM product_details WHERE product_id='$product_spec'");
$retrieve=mysqli_fetch_array($result);

$id=$retrieve['product_id'];
$name=$retrieve['product_name'];
$product_desc=$retrieve['product_desc'];
$product_price=$retrieve['product_price'];
$product_img=$retrieve['product_img'];




$_SESSION['product_spec']="";




?>


<!DOCTYPE html>

<html>

<head>

<title> Assignment 3 Form </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet"  href="css/profpagecard.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>



<body>

<h2 style="text-align:center">User Profile Card</h2>

<div class="card">


  
  <?php echo "<img style='width:50%' src='includes/".$retrieve['product_img']."'>"; ?>
    <h1>  <?php echo $id; ?> </h1>  
  <h2>  <?php echo $name; ?>      </h2>
  <h2>  <?php echo $product_price; ?>      </h2>
    <h2>  <?php echo $product_desc; ?>      </h2>
  <p class="title">CEO & Founder, Example</p>
 
	
	
  
  <p>Harvard University</p>
  
  <p><a href="shoppingpage2.php"> GO BACK</a> </p>
  
    <p><a href="profpageedit.php"> GO TO CART</a> </p>
  
</div>

</body>

</body>




</html>
