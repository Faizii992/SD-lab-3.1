
<?php

include "includes/db.inc.php";
session_start();
include 'header.php';
$uid=$_SESSION['userid'];
$uname=$_SESSION['userUid'];


$result=mysqli_query($conn,"SELECT * FROM users WHERE idusers='$uid'");
$retrieve=mysqli_fetch_array($result);
//print_r($retrieve);

$id=$retrieve['idusers'];
$uid=$retrieve['uidusers'];
$emailusers=$retrieve['emailusers'];
$address=$retrieve['address'];
$gender=$retrieve['gender'];
$number=$retrieve['number'];
$profilepic=$retrieve['profilepic'];
$firstname=$retrieve['firstname'];
$lastname=$retrieve['lastname'];
$bio=$retrieve['bio'];
$workedu=$retrieve['work_edu'];


?>


<!DOCTYPE html>

<html>

<head>

<title> Assignment 3 Form </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet"  href="css/profpagecard.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>



<body>

<h2 style="text-align:center">User Profile Card</h2>

<div class="card">


  
  <?php echo "<img style='width:100%' src='includes/".$retrieve['profilepic']."'>"; ?>
    <h1>  <?php echo $id; ?> </h1>  
  <h2>  <?php echo $uid; ?>      </h2>
  <p class="title">CEO & Founder, Example</p>
      <p class="title"> <?php echo $profilepic; ?>  </p>
  <p class="title"> <?php echo $workedu; ?>  </p>
  <p class="title"> <?php echo $emailusers; ?>  </p>
    <p class="title"> <?php echo $address; ?>  </p>
    <p class="title"> <?php echo $gender; ?>
    <p class="title"> <?php echo $number; ?>
	   <p class="title"> <?php echo $firstname; ?>  </p>
    <p class="title"> <?php echo $lastname; ?>
    <p class="title"> <?php echo $bio; ?>
	
	
	
  
  <p>Harvard University</p>
  
  <p><a href="profpageedit.php"> EDIT PROFILE </a> </p>
</div>

</body>

</body>




</html>
