
<?php
    session_start();
	require 'includes/db.inc.php';
	include 'header.php';


?>







<?php

  	
$_SESSION['product_spec']="";


//$result=mysqli_query($conn,"INSERT into product_details VALUES
//('','$_POST[product_name]','$target_file','$_POST[product_category]',$_POST[product_price],$_POST[product_qty])");

    if (isset($_POST["add"])){
        if (isset($_SESSION["cart"])){
            $item_array_id = array_column($_SESSION["cart"],"product_id");
            if (!in_array($_GET["id"],$item_array_id)){
                $count = count($_SESSION["cart"]);
                $item_array = array(
                   'product_id' => $_GET["id"],
                    'product_name' => $_POST["hidden_name"],
                    'product_price' => $_POST["hidden_price"],
                    'product_qty' => $_POST["product_qty"],
                );
	
				
                $_SESSION["cart"][$count] = $item_array;
											 echo' <div class="alert alert-success">
  <strong>Success!</strong> Added to Cart Successfully!  <a href="shoppingcartdetails.php"> View Cart </a>
</div> ';
               // echo '<script>window.location="shoppingpage2.php"</script>';
	
			
            }   
			
			
			else{
                echo '<script>alert("Product is already Added to Cart")</script>';
               // echo '<script>window.location="shoppingpage2.php"</script>';
			   											 echo' <div class="alert alert-danger">
  <strong>Success!</strong> Added to Cart Successfully!  <a href="shoppingcartdetails.php"> View Cart </a>
</div> ';
          
			   
            }
        }else{
            $item_array = array(
             'product_id' => $_GET["id"],
                    'product_name' => $_POST["hidden_name"],
                    'product_price' => $_POST["hidden_price"],
                    'product_qty' => $_POST["product_qty"],
              
            );
            $_SESSION["cart"][0] = $item_array;
        }
    }
    if (isset($_GET["action"])){
        if ($_GET["action"] == "delete"){
            foreach ($_SESSION["cart"] as $keys => $value){
                if ($value["product_id"] == $_GET["id"]){
                    unset($_SESSION["cart"][$keys]);
                    echo '<script>alert("Product has been Removed...!")</script>';

          
                    echo '<script>window.location="shoppingcartdetails.php"</script>';
																					 echo' <div class="alert alert-success">
  <strong>Success!</strong> Product Removed!  <a href="shoppingpage2.php"> Click Here to order again. </a>
</div> ';
                }
            }
        }
    }
?>



<!doctype html>

<html>

<head>
<title>
170104093

</title>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" type="text/css" href="css/shoppingpage.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/header.css">
</head>

<body>




<div class="firstcont">

<div class="container">
<div class="row">

<div class="col-md-4 col-sm-6"> 
<div class="box">
<h1> Free Shipping </h1>
<img src="Images/freeship.png">
<p>For an order over BDT TK 800</p>
  </div>
</div>

<div class="col-md-4 col-sm-6"> 
<div class="box">
<h1> Free Shipping </h1>
<img src="Images/freeship.png">
<p>For an order over BDT TK 800</p>
  </div>
</div>

<div class="col-md-4 col-sm-6"> 
<div class="box">
<h1> Free Shipping </h1>
<img src="Images/freeship.png">
<p>For an order over BDT TK 800</p>
  </div>
</div>
</div>

</div>

</div>

<?php



?>






<div class="blogpostheader">
<p class="MEET"> OUR </p>
<h1 class="OUR_VETS"> PRICES </h1>

</div>


<div class="secondcont">


<form method="post" action="shoppingpage2.php">

  <div class="list-group container-fluid col-md-3">
  

   <div class="btn-group-vertical">
 <button style="margin-bottom 18px;" 
 type="submit" name="Cat food" class="btn btn-info">Cat food</button>
 
 <button style="margin-bottom 18px;" 
 type="submit" name="Dog food" class="btn btn-info">Dog food</button>
 
 <button style="margin-bottom 18px;" 
 type="submit" class="btn btn-info">View Details</button>

 <button style="margin-bottom 18px;" 
 type="submit" class="btn btn-info">View Details</button>
</div>




  </div>
  
  </form>

<div class="container">
<div class="row">


<?php

if(isset($_POST['Cat food']))
{
	
$categ='Cat food';	
}
else if(isset($_POST['Dog food']))
{
	$categ='Dog food';	
	
}

?>


<?php

if(isset($_POST['Cat food']))
{
	
$categ='Cat food';	
}
else if(isset($_POST['Dog food']))
{
	$categ='Dog food';	
	
}

$categ='Cat food';
$result=mysqli_query($conn,"select * FROM product_details where product_category ='$categ'");
while($row=mysqli_fetch_array($result))
	{
		
		
		$_SESSION['productspec']=$row["product_id"];

?>

<div class="col-sm-6 col-md-4"> 



<div class="box">



<form method="post" action="shoppingpage2.php?action=add&id=<?php echo $row["product_id"]; ?>">

                            <div class="product">
							<div class="scndcontimg">

<?php echo "<img src='includes/".$row['product_img']."'>"; ?>
</div>


<h1> <?php echo $row["product_name"]; ?> </h1>
<h3> <?php echo $row["product_price"]; ?></h3>
 <input type="hidden" name="hidden_name" value="<?php echo $row["product_name"]; ?>">
 <input type="hidden" name="hidden_price" value="<?php echo $row["product_price"]; ?>">

<hr>
                                <input type="text" name="product_qty" class="form-control" value="1">
                                <input type="submit" name="add" style="margin-bottom: 10px;" class="btn btn-success"
                                       value="Add to Cart">
									   
									   <button style="margin-bottom 18px;" 
									   onclick="location.href = 'http://localhost/Pawesome/productdetails.php';" type="button" class="btn btn-info">View Details</button>
									   
                            </div>
                        </form>


  
  </div>
  </div>
  


<?php


	}

?>
  
 


  
</div>

</div>

</div>





<div class="footer">

<h1> © Copyright 2017 All Rights Reserved </h1>
</div>

</body>


</html>



