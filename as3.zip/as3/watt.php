<!DOCTYPE html>
<html>
<head>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet"
href="css\bootstrap.min.css" />


</head>

<body>
<?php
$error='';
$firstname ='';
$laststname ='';
$email='';
$no='';
$comment='';

function clean_text($string)
{
 $string = trim($string);
 $string = stripslashes($string);
 $string = htmlspecialchars($string);
 return $string;
}


  $firstname = clean_text($_POST["firstname"]);

 
  $lastname = clean_text($_POST["lastname"]);
  $email = clean_text($_POST["email"]);
  $no = clean_text($_POST["no"]);
   $comment = $_POST["comment"];
  $file_open = fopen("wat.csv", "a");
  $no_rows = count(file("wat.csv"));
  
   $no_rows = ($no_rows - 1) + 1;
  
  $form_data = array(
   'id'  => $no_rows,
   'firstname'  => $firstname,
    'lastname'  => $lastname,
   'email'  => $email,
   'no' => $no,
   'comment'=> $comment,
  );
  fputcsv($file_open, $form_data);
  $firstname = '';
     $laststname = '';
  $email = '';
  $no = '';

  $comment = '';
  

?>
<div class="container">
  <table class="table table-bordered">
  <thead>
  <tr>
      <th> ID </th>
  <th>First Name</th>
    <th>Last Name</th>
  <th>Email</th>

  <th>Phone Number</th>
    <th>Message</th>
</tr>
<tbody>


	<?php
		
        $fp=fopen('wat.csv','r');//read mode
		 $fs=filesize('wat.csv');//we can know file size
		 $separator=",";
		
		 while($row=fgetcsv($fp,$fs,$separator))
		 { echo '<tr>';
			 
			 echo '<td>'.$row[0].'</td>';
			  echo '<td>'.$row[1].'</td>';
			  echo '<td>'.$row[2].'</td>';
          echo '<td>'.$row[3].'</td>';
		  	  echo '<td>'.$row[4].'</td>';
          echo '<td>'.$row[5].'</td>';
			  echo'</tr>';
		 }  
		 
		 
			
	   
		?>
		</tbody>
		</table>
		
</div>
</body>
</html>