<!DOCTYPE html>

<html>

<head>

<title> Assignment 3 mine </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet"  href="css/main.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>


<body>


<div class="col-md-6 leftdiv">

<div class="infobox">


<div class="info">

<div class="iconheading">
<img src="images/download.png">
<h1> Address </h1>

</div>
<p>Mada Center 8th floor,379 Hudson. St New York,NY 10018 US </p>


</div>




<div class="info">

<div class="iconheading">
<img src="images/download.png">
<h1> Address </h1>

</div>
<p>Mada Center 8th floor,379 Hudson. St New York,NY 10018 US </p>


</div>


<div class="info">

<div class="iconheading">
<img src="images/download.png">
<h1> Address </h1>

</div>
<p>Mada Center 8th floor,379 Hudson. St New York,NY 10018 US </p>


</div>
</div>
</div>

<div class="col-md-6 rightdiv">





<div class="box">



<h1> Send Us A Message </h1>
<div class="firstlastname">

<form action="watt.php" method="post">


<div class="name">
<label> TELL US YOUR NAME *</label>

<div class="firstlastnamediv">

 <div class="firstname">  <input  type="text" name="firstname" class="form-control"  value="Firstname" /> </div>

 <div class="lastname"> <input type="text" name="lastname" class="form-control" value="Lastname" /> </div>

</div>

</div>

<label> ENTER YOUR EMAIL * </label>
<input type="email" class="form-control" name="email" value="example@example.com" />


<label> ENTER PHONE NUMBER * </label>
<input type="number" class="form-control" name="no" value="example@example.com" />


<label> MESSAGE * </label>
<div class="messagebox">
<textarea name="comment"  class="form-control" form="usrform">Write us a message.</textarea>
</div>

<div class="button">
<button type="submit" name="submit" class="btn btn-default"> SEND MESSAGE </button>

</div>
</form>

</div>
</div>

</div>


</body>




</html>
